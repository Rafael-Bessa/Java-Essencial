
public interface Embaralhador {

	String embaralha(String palavra);

}
