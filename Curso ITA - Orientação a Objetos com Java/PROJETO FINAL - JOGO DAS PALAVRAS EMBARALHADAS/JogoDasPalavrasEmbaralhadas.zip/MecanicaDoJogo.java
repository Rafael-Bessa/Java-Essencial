public interface MecanicaDoJogo {

	public String mostraPalavraEmbaralhada();

	public String comparaResposta();

	public void errou();

	public void somaPontuacao();

	public int getPontuacao();

	public int getVidas();

}
